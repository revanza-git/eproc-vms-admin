<?php echo $this->session->flashdata('msgSuccess')?>
<div id="container-chart">
	
</div>
	<?php foreach ($item as $key => $_item) {?>
		<!-- <div>
			<h2 style="text-transform: capitalize;"><?php echo $_item["nama"];?></h2>
		</div> -->
	<?php }?>