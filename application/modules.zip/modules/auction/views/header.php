<div class="logo">
	<a href="<?php echo site_url('auction')?>"><img src="<?php echo base_url('assets/images/login-regas-logo.jpg');?>"></a>
</div>
<div class="backButton">
	<ul class="navMenu clearfix">
		<li><a href="<?php echo site_url('auction')?>">Welcome, <?php echo $name?></a></li>
		<li class="last"><a href="<?php echo site_url('main/logout')?>"><i class="fa fa-power-off"></i>&nbsp;Keluar</a></li>
	</ul>
</div>