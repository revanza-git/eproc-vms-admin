<div class="formDashboard">
	<h1>Duplikat Data Auction</h1>
	<form method="POST" enctype="multipart/form-data">
		<table>
			<tr class="input-form">
				<td><label>Masukkan jumlah duplikat</label></td>
				<td>
					<input type="number" name="total" value="1" min="1">
				</td>
			</tr>
		</table>
		
		<div class="buttonRegBox clearfix">
			<input type="submit" value="Duplikat" class="btnBlue" name="simpan">
		</div>
	</form>
</div>